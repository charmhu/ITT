var temp_title=1;
var temp_color=1;
function exchange(){
c
}
function title_color(){


}

function title_colorupgrade(){



}

function BREATH_LED(){

}