from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import get_template
from django.template.context import Context
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.decorators import login_required
from deploy_lib import common as cm
from auto_deploy import deploy_lib
from deploy_lib.vix.manager import Manager
from deploy_lib.xml_helper import load_case_config, save_case_config, save_global_config, load_global_config
import form
import models
import os
import datetime
import time
import tasks
import thread
import xlwt
# Create your views here.



def _saveCaseXml(request):
    """save case xml"""
    case_dic = {}
    for key in ['case_name', 'case_description', 'case_type', 'fta', 'dsn', 'bed_no', 'ftd_name', 'server_delay']:
        if request.POST.has_key(key):
            case_dic[key] = request.POST.get(key)

    list_map = {'func_list' : models.FuncList,
                'computer_list' : models.PCList,
                'tp_name' : models.TpList,
                'res_pool' : models.ResPool,
                'datastore' : models.DataStore,
                'host' : models.HostInfo,
                'clone_type': models.CloneType,
                'cli': models.Cli,
                'exe' : models.TrickClickFiles,
                }

    for key in ['func_list', 'computer_list', 'tp_name', 'res_pool', 'clone_type', 'host', 'datastore', 'cli', 'exe']:
        if request.POST.has_key(key):
            lst = []
            for ob_id in request.POST.getlist(key):
                if not ob_id:
                    continue
                obj = list_map[key].objects.get(id=ob_id)
                lst.append(obj.name)
            case_dic[key] = lst

    for key in ['clone_num']:
        if request.POST.has_key(key):
            lst = request.POST.getlist(key)
            case_dic[key] = lst
    save_case_config(case_dic)


@login_required
def upgrade(request):
    t = get_template('upgrade_bed.html')
    deploy_lib.global_conf_dic = load_global_config()
    if request.method == 'POST':
        uf = form.CaseForm(data=request.POST)
        if uf.is_valid():
            if request.POST.has_key('reload'):
                pc_list = cm.get_computer_list(True)
                print pc_list
                saved_pc_list = models.PCList.objects.all()
                for s_pc in saved_pc_list:
                    for pc in pc_list:
                        if pc == s_pc.name:
                            break
                    else:
                        s_pc.delete()
                
                for pc in pc_list:
                    for s_pc in saved_pc_list:
                        if pc == s_pc.name:
                            break
                    else:
                        p_obj = models.PCList()
                        p_obj.name = pc
                        p_obj.save()
    
            if request.POST.has_key('save'):
                print request.POST
                case_name = request.POST.get('case_name')
                case_objs = models.Case.objects.filter(case_name=case_name)
                if not case_objs:
                    new_case = models.Case()
                    new_case.case_name = request.POST.get('case_name')
                    new_case.case_type = 'upgrade'
                    new_case.status = 'Init'
                    new_case.create_time = datetime.datetime.now()
                    new_case.last_modifi = datetime.datetime.now()
                    new_case.save()
                    _saveCaseXml(request)
                else:
                    #edit case
                    print 'edit case'
                    case_obj = case_objs[0]
                    case_obj.case_name = request.POST.get('case_name')
                    case_obj.last_modifi = datetime.datetime.now()
                    case_obj.save()
                    _saveCaseXml(request)
                return HttpResponseRedirect('/')
            elif request.POST.has_key('back'):
                return HttpResponseRedirect('/')
            
        else:
            return HttpResponse('form arg not valid')

    case_id = request.GET.get('caseid', '')
    if not case_id:
        #in create case page
        pc_list = cm.get_computer_list(True)
        for pc in pc_list:
            pc_lst = models.PCList.objects.filter(name=pc)
            if not pc_lst:
                p = models.PCList()
                p.name = pc
                p.save()
        computer_list = models.PCList.objects.all()
        func_list = models.FuncList.objects.all()
        initial_dic ={'case_name' : 'your case name',
                    'case_description' : 'case description',
                    'computer_list' : computer_list,
                    'func_list' : func_list[4:]
                      }
    else:
        #in edit page
        cases = models.Case.objects.filter(id=case_id)
        if not cases:
            print 'can not find case %s in database' % case_name
            return HttpResponse('can not find %s' % case_name)
        case = cases[0]
        case_name = case.case_name
        dic = load_case_config(case_name)
        computer_list = dic.get('computer_list', [])
        func_list     = dic.get('func_list')
        pc_queryset = []
        for pc in computer_list:
            print 'pc=%s' % pc
            pc_queryset.append(models.PCList.objects.filter(name=pc))
        if computer_list:
            pcq = reduce(addQuery, pc_queryset)
        else:
            pcq = None
        func_queryset = []
        for func in func_list:
            print 'func=%s' % func
            func_queryset.append(models.FuncList.objects.filter(name=func))
        fcq = reduce(addQuery, func_queryset)
        initial_dic ={'case_name' : dic.get('case_name'),
                      'case_description' : dic.get('case_description'),
                      'computer_list' : pcq,
                      'func_list' : fcq
                      }

    uf = form.CaseForm(initial=initial_dic)
    param = {'uf' : uf}
    ct = Context(param)
    html = t.render(ct)
    return HttpResponse(html)

def addQuery(x, y):
    return x|y

def save_config_page(request):
    """save config page"""
    param = {}
    t = get_template('save_config_page.html')
    if request.method == 'POST':
        if request.POST.has_key('main'):
            return HttpResponseRedirect('/')
    deploy_lib.global_conf_dic = load_global_config()
    case_id = request.GET.get('caseid', '')
    cases = models.Case.objects.filter(id=case_id)
    case = cases[0]
    case_name = case.case_name
    case_dic = load_case_config(case_name)
    MG = Manager(case_dic)
    MG.connectServer()
    MG.generateTaskFiles()
    result, msg = check_servertype(MG, case_dic)
    if result == 'Fail':
        param['type_fail'] = 'Fail: %s' % msg
    else:
        param['type_success'] = 'Success: %s' % msg
    check_msg = check_datastore(MG, case_dic)
    datastore_info, host_info ,exist_vm_list = get_info(MG, case_dic)
    if check_msg.find('Success') >= 0:
        param['success_msg'] = check_msg
    else:
        param['fail_msg'] = check_msg
    param['datastore_info'] = datastore_info
    param['host_info'] = host_info
    param['exist_vm_list'] = exist_vm_list
    ct = Context(param)
    html = t.render(ct)
    return HttpResponse(html)

@login_required
def template(request):
    """install from template"""
    t = get_template('new_bed_from_template.html')
    param = {}
    if request.method == 'POST':
        print '##############'
        print request.POST
        print '##############'
        if request.POST.has_key('flush_vcenter'):
            _flush_vcenter_info()
        if request.POST.has_key('add'):
            length =int(length) + 1
            request.session['len'] = str(length)

        if request.POST.has_key('back'):
            return HttpResponseRedirect('/')
        if request.POST.has_key('save'):
            print request.POST
            case_name = request.POST.get('case_name')
            case_objs = models.Case.objects.filter(case_name=case_name)
            if not case_objs:
                new_case = models.Case()
                new_case.case_name = request.POST.get('case_name')
                new_case.case_type = 'template'
                new_case.status = 'Init'
                new_case.create_time = datetime.datetime.now()
                new_case.last_modifi = datetime.datetime.now()
                new_case.save()
                caseid = new_case.id
                _saveCaseXml(request)
            else:
                #edit case
                print 'edit case'
                case_obj = case_objs[0]
                case_obj.case_name = request.POST.get('case_name')
                case_obj.last_modifi = datetime.datetime.now()
                case_obj.save()
                caseid = case_obj.id
                _saveCaseXml(request)
            return HttpResponseRedirect('/')
        if request.POST.has_key('check'):
            case_name = request.POST.get('case_name')
            case_objs = models.Case.objects.filter(case_name=case_name)
            case_obj = case_objs[0]
            caseid = case_obj.id
            return HttpResponseRedirect('/save_config_page/?caseid=%s' % caseid)
    case_id = request.GET.get('caseid', '')
    if not case_id:
        #in create case page
        func_list = models.FuncList.objects.all()            
        initial_dic ={'case_name' : 'your case name',
                    'case_description' : 'case description',
                    'dsn' : 'dsn server',
                    'fta' : 'fta server',
                    'ftd_name' : 'ftd name',
                    'bed_no' : 1,
                    'server_delay' : 0,
                    'func_list' : func_list    
                          }
        param['clone_form_list'] = []
        clone_case_form = form.CloneCaseForm(initial=initial_dic)
    else:
        #in edit page
        cases = models.Case.objects.filter(id=case_id)
        if not cases:
            print 'can not find case %s in database' % case_name
            return HttpResponse('can not find %s' % case_name)
        case = cases[0]
        case_name = case.case_name
        clone_form_list = []
        cli_form_list = []
        dic = load_case_config(case_name)
        basic_initial_dic = {}
        for key in ['case_name', 'case_description', 'fta', 'dsn', 'bed_no', 'ftd_name', 'server_delay']:
            basic_initial_dic[key] = dic.get(key)
        func_list = dic.get('func_list')
        func_queryset = []
        for func in func_list:
            print 'func=%s' % func
            func_queryset.append(models.FuncList.objects.filter(name=func))
        fcq = reduce(addQuery, func_queryset)
        basic_initial_dic['func_list'] = fcq
        clone_case_form = form.CloneCaseForm(initial=basic_initial_dic)
        clone_form_list = []
        print 'dic============='
        print dic
        tp_lst = dic.get('tp_name',[])
        data_len = len(tp_lst)
        print 'data len = %s' % data_len
        for i in range(data_len):
            initial_dic = _getCloneInitialDic(dic, i)
            print 'clone initial dic'
            print initial_dic
            clone_form_list.append(form.CloneConfigForm(initial=initial_dic))

        param['clone_form_list'] = clone_form_list
        print 'dic ======='
        print dic

        cli_lst = dic.get('cli',[])
        cli_len = len(cli_lst)
        print 'data len = %s' % cli_len
        for i in range(cli_len):
            initial_dic = _getCliInitialDic(dic, i)
            print 'CliInitialDic'
            print initial_dic
            cli_form_list.append(form.CliExeForm(initial=initial_dic))
        param['cli_form_list'] = cli_form_list
        

    param['cli']   = form.CliExeForm()
    param['clone'] = form.CloneConfigForm()
    param['form']  = clone_case_form


    ct = Context(param)
    html = t.render(ct)
    return HttpResponse(html)

def _getCliInitialDic(dic, i):
    """get cli initial dic"""
    cli_name = dic.get('cli')[i]
    exe_name = dic.get('exe')[i]
    cli_q = models.Cli.objects.filter(name=cli_name)
    exe_q = models.TrickClickFiles.objects.filter(name=exe_name)
    initial_dic = {'cli' : cli_q[0], 'exe' : exe_q[0]}
    return initial_dic

def _getCloneInitialDic(dic, i):
    """get clone initial dic"""
    tp_name = dic.get('tp_name')[i]
    res_pool = dic.get('res_pool')[i]
    clone_type = dic.get('clone_type')[i]
    host = dic.get('host')[i]
    datastore = dic.get('datastore')[i]
    clone_num = dic.get('clone_num')[i]
    tp_q = models.TpList.objects.filter(name=tp_name)
    res_q = models.ResPool.objects.filter(name=res_pool)
    clone_q = models.CloneType.objects.filter(name=clone_type)
    host_q = models.HostInfo.objects.filter(name=host)
    datastore_q = models.DataStore.objects.filter(name=datastore)
    initial_dic = {
                   'tp_name': tp_q[0],
                   'res_pool': res_q[0],
                   'clone_type': clone_q[0],
                   'host': host_q[0],
                   'datastore': datastore_q[0],
                   'clone_num': clone_num,   # modified on 11/2/2015, fix the defect computer number can't greater than ten          
        }
    return initial_dic

@login_required
def from_ghost(request):
    t = get_template('new_bed_from_ghost.html')
    param = {
        'person_name' : 'jams bond',
        'company' : 'FBI',
    }
    ct = Context(param)
    html = t.render(ct)
    return HttpResponse(html)

@login_required
def main(request):
    """main page of deploy"""
    t = get_template('main.html')
    mf = form.OpForm()
    download_cfg_lst = models.GlobalOptionDownload.objects.all()
    if download_cfg_lst:
        dc = download_cfg_lst[0]
        initial_dic = {'path' : dc.path, 'user' : dc.user, 'passwd' : dc.passwd, 'install_pack_name': dc.install_pack_name}
        d = form.DownloadForm(initial=initial_dic)
    else:
        d = form.DownloadForm()
        dc = models.GlobalOptionDownload()
    param = {}
    case_info = []
    param['mf'] = mf
    param['d'] = d

    if request.method == 'POST':
        if request.POST.has_key('save'):
            dc.saveFromRequest(request.POST)
            initial_dic = {'path' : dc.path, 'user' : dc.user, 'passwd' : dc.passwd, 'install_pack_name': dc.install_pack_name}
            d = form.DownloadForm(initial=initial_dic)
            param['d'] = d
        if request.POST.has_key('download'):
            #download from url
            print request.POST
            d = form.DownloadForm(request.POST)
            if not cm.download_install_pack():
                return render(request, 'main.html', {'data': "failed"})
            return render(request, 'main.html', {'data': "successed"})
        if request.POST.has_key('create'):
            mf = form.OpForm(request.POST)
            if mf.is_valid():
                op = request.POST.get('op_type')
                op_type = models.OP.objects.get(id=op).op_type
                return HttpResponseRedirect(op_type)
        if request.POST.has_key('edit'):
            case_name = request.REQUEST.get('casename')
            case_obj = models.Case.objects.get(case_name=case_name)
            case_id = case_obj.id
            case_type = case_obj.case_type
            return HttpResponseRedirect('/%s/?caseid=%s' % (case_type, case_id))
        if request.POST.has_key('delete'):
            case_name = request.REQUEST.get('casename')
            case_obj = models.Case.objects.get(case_name=case_name)
            case_obj.delete()
            map_obj_lst = models.ServerIpMap.objects.filter(case_name=case_name)
            for map_obj in map_obj_lst:
                map_obj.delete()
            status_obj = models.TaskStatus.objects.filter(case_name=case_name)
            for status in status_obj:
                status.delete()
            case_xml_path = os.path.join(deploy_lib.WORK_DIR, r'config\cases\%s.xml' % case_name)
            if os.path.exists(case_xml_path):
                os.remove(case_xml_path)
            cm.clean()
            status_obj = models.TaskStatus.objects.filter(case_name=case_name)
            for status in status_obj:
                status.delete()
        if request.POST.has_key('clean'):
            case_name = request.POST.get('casename')
            case_obj = models.Case.objects.get(case_name=case_name)
            cm.clean()
            status_obj = models.TaskStatus.objects.filter(case_name=case_name)
            for status in status_obj:
                status.delete()
            case_obj.status = 'saved'
            case_obj.save()
        if request.POST.has_key('run'):
            print request.POST
            case_name = request.POST.get('casename')
            case_obj = models.Case.objects.get(case_name=case_name)
            tp = tasks.getthreadpool()
            case_dic = load_case_config(case_name)
            tp.add_task(tasks.run_deploy, case_dic)
            #thread.start_new_thread(tasks.wait_tasks, (case_name,))
            return HttpResponseRedirect('/running/?caseid=%s' % case_obj.id)
        if request.POST.has_key('result'):
            case_name = request.POST.get('casename')
            case_obj = models.Case.objects.get(case_name=case_name)
            if not case_obj:
                HttpResponse('case name not found')
            return HttpResponseRedirect('/get_result/?caseid=%s' % case_obj.id)
            #return HttpResponseRedirect('/result/?caseid=%s' % case_obj.id)
        if request.POST.has_key('view'):
            case_name = request.POST.get('casename')
            case_obj = models.Case.objects.get(case_name=case_name)
            return HttpResponseRedirect('/running/?caseid=%s' % case_obj.id)  
    case_list = models.Case.objects.all()
    param['case_list'] = case_list
    ct = Context(param)
    html = t.render(ct)            
    return HttpResponse(html)

@login_required
def get_result(request, caseid=''):
    """get result page"""
    if request.method == 'POST':
        if request.POST.has_key('back'):
            return HttpResponseRedirect('/')
    t = get_template('get_result.html')
    param = {}
    case_id = request.GET.get('caseid')
    case_obj = models.Case.objects.get(id=case_id)
    tm = form.TimeForm()
    case_name = case_obj.case_name
    param['case_name'] = case_name
    param['tm'] = tm
    if request.method == 'POST':
        print request.POST
        datetime = request.POST.get('datetime')
        case_name = request.POST.get('casename')
        if request.POST.has_key('check'):
            print datetime
            print case_name
            return HttpResponseRedirect('/result/?casename=%s&datetime=%s' % (case_name, datetime)) 
    ct = Context(param)
    html = t.render(ct)            
    return HttpResponse(html)


@login_required
def delete_vm(request):
    """delete vm page"""
    t = get_template('delete_vm_page.html')
    param = {}

    if request.method == 'POST':
        if request.POST.has_key('refresh'):

            deploy_lib.global_conf_dic = load_global_config()
            MG = Manager()
            MG.connectServer()
            vm_list = MG.vs.get_registered_vms('ALL') or []
            vms = MG.getVirtualMachine(vm_list)
            for vm in vms:
                vm_obj = models.VMList.objects.filter(name=vm)
                if not vm_obj:
                    vmo = models.VMList()
                    vmo.name = vm
                    vmo.save()
            
        if request.POST.has_key('delete'):
            print request.POST
            vml = request.POST.getlist('vm')
            deploy_lib.global_conf_dic = load_global_config()
            MG = Manager()
            MG.connectServer()
            for vm_id in vml:
                vm_objs = models.VMList.objects.filter(id=vm_id)
                if not vm_objs:
                    print "can not find vm objs"
                vm_obj = vm_objs[0]
                MG.deleteVMByName(vm_obj.name)
        if request.POST.has_key('back'):
            return HttpResponseRedirect('/')

    param['vm'] = form.VMForm()   
    ct = Context(param)
    html = t.render(ct)            
    return HttpResponse(html)

@login_required
def result(request, casename='', datetime=''):
    if request.method == 'POST':
        if request.POST.has_key('back'):
            return HttpResponseRedirect('/')
    t = get_template('result.html')
    param = {}
    case_name = request.GET.get('casename')

    case_obj = models.Case.objects.get(case_name=case_name)
    datetime = request.GET.get('datetime')
    print 'case_name =%s' % case_name
    print 'datetime =%s' % datetime

    case_dic = load_case_config(case_name)
    time_stamp = time.strftime('%m_%d_%H_%M_%S')
    bak_dir = r'c:\PerfAnalysis\PerfBak_%s' % time_stamp

    deploy_lib.global_conf_dic = load_global_config()
    MG = Manager(case_dic)
    MG.connectServer()
    MG.generateTaskFiles()
    computer_list = cm.get_computer_list(True)

    tp = tasks.getThreadPool()
    tp.add_task(cm.checkResult, computer_list, time_stamp, datetime)

    pc_num = len(computer_list)

    result_str = "after about %s minutes ,you can get check result in %s" % (pc_num * 2, bak_dir)
    ct = Context(param)
    html = t.render(ct)            
    return HttpResponse(result_str)

@login_required
def show_case(request, caseid=''):
    if request.method == 'POST':
        if request.POST.has_key('back'):
            return HttpResponseRedirect('/')
    t = get_template('case_detail_status.html')
    param = {}
    case_id = request.GET.get('caseid')
    print 'caseid= %s' % case_id
    case_obj = models.Case.objects.get(id=case_id)
    case_name = case_obj.case_name
    if not case_obj:
        return HttpResponse('can not find %s' % case_name)
    try:
        task_status_obj = models.TaskStatus.objects.filter(case_name=case_name)
    except Exception, e:
        task_status_obj = []
    param['case'] = case_obj
    param['tasks'] = task_status_obj
    ct = Context(param)
    html = t.render(ct)            
    return HttpResponse(html)

@login_required
def upload_computer_role(request):
    param = {}
    t = get_template('import_file.html')
    fm = form.Form(request.POST, request.FILES)
    if fm.is_valid():
        _handle_uploaded_file(request.FILES['headImg'])
        ct = Context(param)

        return render(request, 'import_file.html', {'data': "success"})
    else:
        fm = form.Form()
        param['fm'] = fm
        ct = Context(param)
        html = t.render(ct)
        return HttpResponse(html)

@login_required
def advance_setting(request):
    """advance setting page"""
    param = {}
    t = get_template('advance_setting.html')
    if request.method == 'POST':
        print request.POST
        g_form = form.GlobalOptionsForm(request.POST)
        if request.POST.has_key('save'):
            if g_form.is_valid():
                save_global_config(request.POST)
        if request.POST.has_key('back'):
            return HttpResponseRedirect('/')
    dic = load_global_config()
    param['form'] = form.GlobalOptionsForm(initial=dic)
    ct = Context(param)
    html = t.render(ct)
    return HttpResponse(html)

def _handle_uploaded_file(f):
    dst_file = os.path.join(deploy_lib.WORK_DIR, r'config\computers_and_roles.txt')
    if not os.path.exists(dst_file):
        print "file not exist"
    destination = open(dst_file,'wb+')
    for chunk in f.chunks():
        destination.write(chunk)
    destination.close()

def _clean_table(obj_list):
    if obj_list:
        for obj in obj_list:
            obj.delete()

def _flush_vcenter_info():
    """flush vcenter info"""
    print 'flush begin'
    deploy_lib.global_conf_dic = load_global_config()
    MG = Manager.getInstance()
    MG.connectServer()
    obj_lst = []
    vm_list = MG.vs.get_registered_vms('ALL')
    tp_list = MG.getTemplates(vm_list)
    host_list = MG.vs.get_all_hosts().values()
    datastore_list = MG.vs.get_all_datastores().values()
    res_list    = MG.vs.get_all_resource_pools().values()
    for tp in tp_list:
        tp_objs = models.TpList.objects.filter(name=tp)
        if not tp_objs:
            tp_obj = models.TpList()
            tp_obj.name = tp
            tp_obj.save()
    for tp_obj in models.TpList.objects.all():
        if tp_obj.name not in tp_list:
            tp_obj.delete()

    for datastore in datastore_list:
        d_objs = models.DataStore.objects.filter(name=datastore)
        if not d_objs:
            d = models.DataStore()
            d.name = datastore
            d.save()
    for d in models.DataStore.objects.all():
        if d.name not in datastore_list:
            d.delete()

    for host in host_list:
        host_objs = models.HostInfo.objects.filter(name=host)
        if not host_objs:
            h = models.HostInfo()
            h.name = host
            h.save()
            datastores = MG.vs.get_datastore_by_hosts(host)
            if not datastores:
                print 'get datastore by host failed'
                continue
            for d in datastores:
                d, _ = models.DataStore.objects.get_or_create(name=d)

                h.datastores.add(d)
            exist_datastores = h.datastores.all()
            for ed in exist_datastores:
                if ed.name not in datastores:
                    h.datastores.remove(ed)

        
    for host_obj in models.HostInfo.objects.all():
        if host_obj.name not in host_list:
            for d in host_obj.datastores.all():
                host_obj.datastores.remove(d)
            host_obj.delete()

    for res in res_list:
        r_objs = models.ResPool.objects.filter(name=res)
        if not r_objs:
            res_obj = models.ResPool()
            res_obj.name = res
            res_obj.save()
    for r in models.ResPool.objects.all():
        if r.name not in res_list:
            r.delete()


def check_servertype(MG, case_dic):
    """check server and template relationship"""
    clone_type_list = case_dic.get('clone_type')
    tp_name_list = case_dic.get('tp_name')
    msg = ''
    result = 'Success'
    length = len(clone_type_list)
    for i in range(length):
        clone_type = clone_type_list[i]
        tp_name = tp_name_list[i]
        if not MG.vs.getVM(tp_name):
            result = 'Fail'
            msg += 'template %s not exist\n'
        if clone_type == 'FTD':
            if tp_name.upper().find('FTD') < 0:
                result = 'Fail'
                msg += 'template %s and clone type %s not match\n' % (tp_name, clone_type)
        if clone_type.upper().find('SERVERPRI') >= 0:
            if tp_name.upper().find('SERVERPRI') < 0:
                result = 'Fail'
                msg += 'template %s and clone type %s not match\n' % (tp_name, clone_type)
            else:
                if MG.vs.getVM(tp_name.replace('Pri', 'Sec')) < 0:
                    result = 'Fail'
                    msg += 'template %s not exist\n'                    

    return (result, msg)


def check_datastore(MG, case_dic):
    """check datastore"""
    datastore_dic = {}
    print '#######################################'
    print MG.clone_arg_list
    for dic in MG.clone_arg_list:
        print '##################!!!!!!!!!!!!!!!!!!!!'
        print dic
        print '###############!!!!!!!!!!!!!!!!!!!!!!'
        vm_name = dic.get('vm_name')
        if MG.vs.getVM(vm_name):
            print 'vm %s exists' % vm_name
            continue
        host = dic.get('host', None)
        hmor = MG.vs.get_host_by_name(host)
        prop = MG.vs.get_viproperty(hmor)
        if prop.runtime.connectionState == 'disconnected':
            return 'FAIL: host %s is disconnected' % host
        host_datastore = MG.vs.get_datastore_by_hosts(host)
        datastore = dic.get('datastore', None)
        datastore_info = MG.vs.get_datastore_info(datastore)
        if  not datastore_dic.get(datastore, None):
            datastore_dic[datastore] = datastore_info['free']
        data_free = datastore_dic[datastore]
        tp_name = dic.get('template')
        if tp_name.upper().find('WIN7') >=0 or tp_name.upper().find('WIN8') >= 0:
            data_free -= 40
        else:
            data_free -= 60
        if data_free < 30:
            return 'Fail: datastore %s not enough' % datastore
        datastore_dic[datastore] = data_free

        if datastore not in host_datastore:
            return ('Fail: host %s and datastore %s can not be match' % (host, datastore))
    return 'Success: check config success'

def get_info(MG, case_dic):
    """get datastore and host info"""
    datastore_dic = {}
    host_dic = {}
    exists_vm_list = []
    del exists_vm_list[:]

    for dic in MG.clone_arg_list:
        host = dic.get('host', None)
        datastore = dic.get('datastore', None)
        vm_name = dic.get('vm_name')
        print '-------------------------------------'
        print vm_name
        if MG.vs.getVM(vm_name):
            exists_vm_list.append(vm_name)
        if  not datastore_dic.get(datastore, None):
            datastore_dic[datastore] = MG.vs.get_datastore_info(datastore)
        if not host_dic.get(host, None):
            host_dic[host] = MG.vs.get_host_info(host)

    return (datastore_dic, host_dic, exists_vm_list)
