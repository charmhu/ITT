下载后解压，有两个文件夹，templates、site_media、和一个views.py文件。


把templates、site_media文件夹放到C:\itt_auto\itt_auto路径下，替换掉原来的templates、site_media文件夹。


到C:\itt_auto\auto_deploy路径下。删除原来的views.py,跟views.pyc，把新的views.py文件放进去即可。